# BNB_Price_Prediction
- Applied Stats - Project : BNB Price Prediction  - NYC Dataset , predict price of bnb in NYC 
